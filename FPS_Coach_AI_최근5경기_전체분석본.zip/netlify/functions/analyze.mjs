import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers });
}

export default async function handler(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers });
  }

  if (req.method !== "POST") {
    return json({ error: "POST 요청만 허용됩니다." }, 405);
  }

  if (!process.env.OPENAI_API_KEY) {
    return json({ error: "OPENAI_API_KEY가 설정되지 않았습니다." }, 500);
  }

  try {
    const body = await req.json();

    const instructions = `
너는 FPS 경기 데이터를 설명하는 코칭 AI다.

반드시 지켜라:
- 실제 게임플레이, 리플레이, 로그를 본 것처럼 말하지 않는다.
- 입력 데이터에 없는 행동을 추측하지 않는다.
- 서버가 선정한 primaryWeakness 외에 새로운 문제를 만들어내지 않는다.
- 한 경기의 수치만으로 지속적인 플레이 습관을 단정하지 않는다.
- 최근 평균과 비교할 수 있을 때 실제 숫자를 사용한다.
- 경기 수가 적으면 분석 신뢰도가 낮다는 점을 반영한다.
- 다음 경기 목표는 정확히 하나만 제시한다.
- 간결하고 전문적인 한국어를 사용한다.

JSON 형식만 반환한다:
{
  "summary": "핵심 요약 1~2문장",
  "strength": "확인된 강점 1문장",
  "improvement": "선정된 개선점 1~2문장",
  "evidence": "실제 수치에 근거한 설명 1~2문장",
  "nextGoal": "다음 경기 목표 1개"
}
`;

    const response = await client.responses.create({
      model: "gpt-5",
      instructions,
      input: JSON.stringify(body),
      text: {
        format: {
          type: "json_object"
        }
      }
    });

    let result;

    try {
      result = JSON.parse(response.output_text);
    } catch {
      return json(
        { error: "AI 응답 형식 오류" },
        502
      );
    }

    return json(result);
  } catch (error) {
    console.error("FPS Coach AI error:", error);

    return json(
      {
        error: "AI 분석 중 오류가 발생했습니다."
      },
      500
    );
  }
}

export const config = {
  path: "/.netlify/functions/analyze"
};
