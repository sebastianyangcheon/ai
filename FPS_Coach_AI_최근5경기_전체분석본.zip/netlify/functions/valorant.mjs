const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers });
}

const VALID_REGIONS = new Set(["kr", "ap", "na", "eu", "latam", "br"]);

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, Number(value) || 0));
}

function normalizeMatch(match, name, tag) {
  const players = Array.isArray(match?.players) ? match.players : [];
  const player = players.find(p =>
    String(p?.name || "").toLowerCase() === name.toLowerCase() &&
    String(p?.tag || "").toLowerCase() === tag.toLowerCase()
  );
  if (!player) return null;

  const stats = player.stats || {};
  const kills = Number(stats.kills) || 0;
  const deaths = Number(stats.deaths) || 0;
  const assists = Number(stats.assists) || 0;
  const shots = (Number(stats.headshots) || 0) + (Number(stats.bodyshots) || 0) + (Number(stats.legshots) || 0);
  const headshot = shots ? Math.round((Number(stats.headshots) / shots) * 1000) / 10 : 0;

  const teamId = player.team_id;
  const teams = Array.isArray(match?.teams) ? match.teams : [];
  const team = teams.find(t => t.team_id === teamId);
  const result = team?.won === true ? "win" : "loss";

  // HenrikDev does not expose the project's old "accuracy" and "position" fields.
  // Use conservative derived values rather than pretending they are official stats.
  const accuracy = clamp(Math.round((Number(stats.headshots) + Number(stats.bodyshots)) / Math.max(1, shots) * 1000) / 10);
  const impact = clamp(Math.round((kills / Math.max(1, deaths)) * 50));
  const position = clamp(60);

  return {
    id: match?.metadata?.match_id || null,
    map: match?.metadata?.map?.name || "Unknown",
    mode: match?.metadata?.queue?.name || "Unknown",
    startedAt: match?.metadata?.started_at || null,
    result,
    kills,
    deaths,
    assists,
    headshot,
    accuracy,
    impact,
    position,
    agent: player?.agent?.name || null
  };
}

export default async function handler(req) {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return json({ error: "POST 요청만 허용됩니다." }, 405);

  const apiKey = process.env.HENRIKDEV_API_KEY;
  if (!apiKey) return json({ error: "HENRIKDEV_API_KEY가 Netlify 환경변수에 설정되지 않았습니다." }, 500);

  try {
    const body = await req.json();
    const name = String(body?.name || "").trim();
    const tag = String(body?.tag || "").trim();
    const region = String(body?.region || "kr").toLowerCase();
    const platform = String(body?.platform || "pc").toLowerCase();
    const size = Math.min(10, Math.max(1, Number(body?.size) || 5));

    if (!name || !tag) return json({ error: "닉네임과 태그가 필요합니다." }, 400);
    if (!VALID_REGIONS.has(region)) return json({ error: "지원하지 않는 지역입니다." }, 400);
    if (!["pc", "console"].includes(platform)) return json({ error: "지원하지 않는 플랫폼입니다." }, 400);

    const url = new URL(
      `https://api.henrikdev.xyz/valorant/v4/matches/${region}/${platform}/${encodeURIComponent(name)}/${encodeURIComponent(tag)}`
    );
    url.searchParams.set("size", String(size));
    url.searchParams.set("mode", "competitive");

    const response = await fetch(url, {
      headers: {
        "Authorization": apiKey,
        "Accept": "*/*"
      }
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      const message =
        response.status === 404 ? "해당 Riot ID의 경쟁전 데이터를 찾지 못했습니다." :
        response.status === 429 ? "API 요청이 너무 많습니다. 잠시 후 다시 시도해주세요." :
        response.status === 403 ? "API 접근이 거부되었습니다. API 키 또는 서비스 상태를 확인해주세요." :
        `HenrikDev API 오류 (${response.status})`;
      return json({ error: message }, response.status);
    }

    const rawMatches = Array.isArray(data?.data) ? data.data : [];
    const matches = rawMatches.map(m => normalizeMatch(m, name, tag)).filter(Boolean);

    return json({ name, tag, region, matches });
  } catch (error) {
    console.error("HenrikDev API error:", error);
    return json({ error: "VALORANT 전적을 불러오는 중 오류가 발생했습니다." }, 500);
  }
}

export const config = {
  path: "/.netlify/functions/valorant"
};
